-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2015 at 03:32 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intranet`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendences`
--

CREATE TABLE IF NOT EXISTS `attendences` (
`id` int(11) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `intime` varchar(111) DEFAULT NULL,
  `outtime` varchar(111) DEFAULT NULL,
  `ecomment` varchar(1111) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `attendences`
--

INSERT INTO `attendences` (`id`, `employee_id`, `intime`, `outtime`, `ecomment`, `date`) VALUES
(2, 0, '13:10:00', '00:00:00', '', '0000-00-00 00:00:00'),
(3, 0, '13:25:47', '00:00:00', '', '0000-00-00 00:00:00'),
(4, 0, NULL, '13:27:03', '', '0000-00-00 00:00:00'),
(5, 0, '15:57:25', '00:00:00', '', '2015-08-12 15:57:25'),
(7, 0, '15:58:48', '00:00:00', '', '2015-08-12 15:58:48'),
(24, 2, '16:18:58', NULL, '', '2015-08-12 16:18:58'),
(25, 2, NULL, '16:19:10', '', '2015-08-12 16:19:10'),
(50, 1, '5:19 pm', '5:20 pm', '', '2015-08-17 17:19:56');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
`id` int(11) NOT NULL,
  `name` varchar(111) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(1, 'web Development');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
`id` int(15) NOT NULL,
  `email` varchar(41) NOT NULL,
  `password` varchar(200) NOT NULL,
  `full_name` varchar(25) NOT NULL,
  `cell` varchar(13) NOT NULL,
  `nid` int(11) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `designation` char(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `doc1` varchar(111) NOT NULL,
  `doc2` varchar(17) NOT NULL,
  `doc3` varchar(111) NOT NULL,
  `ch_signature` varchar(71) NOT NULL COMMENT 'card holder signature',
  `bank_name` varchar(31) NOT NULL,
  `status` enum('active','blocked') NOT NULL,
  `role` varchar(111) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `email`, `password`, `full_name`, `cell`, `nid`, `dob`, `designation`, `department_id`, `doc1`, `doc2`, `doc3`, `ch_signature`, `bank_name`, `status`, `role`) VALUES
(1, 'sattar@gmail.com', '38b9062c287fad72d20e920e01c68bbc4a65eaf51aefc818ec011627441cfead', 'sattar', '', 0, '2015-07-29 08:45:52', 'Web Application Developer', 0, '1439468574.jpg', '', '0', '', '', 'active', 'sadmin'),
(2, 'lemonpstu09@gmail.com', '38b9062c287fad72d20e920e01c68bbc4a65eaf51aefc818ec011627441cfead', 'lemon kazi', '01840478812', 15486622, '2015-08-12 14:10:50', 'W', 0, '1439468574.jpg', '', '', '', 'sdasde', 'active', ''),
(3, 'sattar15@gmail.com', '15781d07ef531d50f794c311df797b6d0b2b4695fba76515b2adea62c575b7ca', 'lemon kazi', '+880184047881', 41654654, '2015-08-13 12:12:55', 'dasd', 1, '1439468574.jpg', '', '', '', '1564', 'active', ''),
(4, 'abdullah88miah@gmail.com', '15781d07ef531d50f794c311df797b6d0b2b4695fba76515b2adea62c575b7ca', 'abdulah', '01721003717', 2147483647, '2015-08-13 12:22:54', 'junior developer', 1, '1439468574.jpg', '', '', '', 'Islamic Bank', 'active', '');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(11) NOT NULL,
  `content` varchar(1111) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `status` enum('active','blocked') NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendences`
--
ALTER TABLE `attendences`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendences`
--
ALTER TABLE `attendences`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
MODIFY `id` int(15) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
